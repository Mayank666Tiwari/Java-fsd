package assistedproject2;

public class AccessModifiersExample {
	
	    public int publicVariable = 10;
	    private int privateVariable = 20;
	    protected int protectedVariable = 30;
	    int defaultVariable = 40;  // Default access modifier

	    public void publicMethod() {
	        System.out.println("This is a public method.");
	    }

	    private void privateMethod() {
	        System.out.println("This is a private method.");
	    }

	    protected void protectedMethod() {
	        System.out.println("This is a protected method.");
	    }

	    void defaultMethod() {
	        System.out.println("This is a default method.");
	    }

	 
	       
	public static void main(String[] args)
{
		  AccessModifiersExample obj = new AccessModifiersExample();

	        System.out.println("Public variable: " + obj.publicVariable);
	        System.out.println("Private variable: " + obj.privateVariable);
	        System.out.println("Protected variable: " + obj.protectedVariable);
	        System.out.println("Default variable: " + obj.defaultVariable);

	        obj.publicMethod();
	        obj.privateMethod();
	        obj.protectedMethod();
	        obj.defaultMethod();

	}

}
