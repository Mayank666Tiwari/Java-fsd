/**
 * 
 */
/**
 * 
 */
module assistedproject2 {
}