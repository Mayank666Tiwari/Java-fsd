package assistedproject20;

public class ArrayRotation 
{

	public static void main(String[] args) 
	{
		
		 int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
	        
	        System.out.println("Original array:");
	        printArray(array);
	        
	        int rotationSteps = 5; 
	        
	        rightRotateArray(array, rotationSteps);
	        
	        System.out.println("Right rotated array by " + rotationSteps + " steps:");
	        printArray(array);
	    }
	    
	    public static void rightRotateArray(int[] array, int steps) 
	    {
	        int length = array.length;
	        steps = steps % length; 
	        
	        reverseArray(array, 0, length - 1); 
	        reverseArray(array, 0, steps - 1);
	        reverseArray(array, steps, length - 1); 
	    }
	    
	    public static void reverseArray(int[] array, int start, int end) 
	    {
	        while (start < end) {
	            int temp = array[start];
	            array[start] = array[end];
	            array[end] = temp;
	            start++;
	            end--;
	        }
	    }
	    
	    public static void printArray(int[] array) 
	    {
	        for (int num : array) 
	        {
	            System.out.print(num + " ");
	        }
	        System.out.println();


	}

}
