/**
 * 
 */
/**
 * 
 */
module exponentialSearch32 {
}