package rangequeries22;

public class ElementSumInRange {

	public static void main(String[] args) {
		
		int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int L = 2; 
        int R = 7; 
        
        System.out.println("Array:");
        printArray(array);
        
        int sum = calculateSumInRange(array, L, R);
        
        System.out.println("Sum of elements in the range of " + L + " and " + R + ": " + sum);
    }
    
    public static int calculateSumInRange(int[] array, int L, int R) {
        if (L < 0 || R >= array.length || L > R) {
            System.out.println("Invalid range!");
            return 0;
        }
        
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += array[i];
        }
        
        return sum;
    }
    
    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();

	}

}
