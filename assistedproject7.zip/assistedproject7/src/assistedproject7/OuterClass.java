package assistedproject7;

public class OuterClass 
{
	 private int outerData;

	    public OuterClass(int outerData) 
	    {
	        this.outerData = outerData;
	    }

	    public void outerMethod() 
	    {
	        System.out.println("Outer Method");
	    }

	   
	    public class InnerClass 
	    {
	        public void innerMethod() 
	        {
	            System.out.println("Inner Method");
	            System.out.println("Outer Data: " + outerData);
	            outerMethod();
	        }
	    }
	        

	public static void main(String[] args) 
	{
		 OuterClass outer = new OuterClass(10);
	        OuterClass.InnerClass inner = outer.new InnerClass();

	        inner.innerMethod();
	  }
}


	    
	    


 

