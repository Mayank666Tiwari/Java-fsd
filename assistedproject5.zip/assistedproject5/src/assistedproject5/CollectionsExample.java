package assistedproject5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class CollectionsExample 
{
	

	public static void main(String[] args) {
		
		 List<String> list = new ArrayList<>();
	        list.add("Apple");
	        list.add("Banana");
	        list.add("Orange");

	        System.out.println("List:");
	        for (String item : list) {
	            System.out.println(item);
	        }

	     
	        Set<Integer> set = new HashSet<>();
	        set.add(10);
	        set.add(20);
	        set.add(30);

	        System.out.println("\nSet:");
	        for (int item : set) {
	            System.out.println(item);
	        }

	     
	        Map<String, Integer> map = new HashMap<>();
	        map.put("One", 1);
	        map.put("Two", 2);
	        map.put("Three", 3);

	        System.out.println("\nMap:");
	        for (Map.Entry<String, Integer> entry : map.entrySet()) {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	}

}
}
