package assistedproject10;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Matcher is a Java class used to match a regular expression pattern to an input String.
// find() method in Java is used to search for occurrences of the pattern in the input 
// string. The method returns true if the pattern is found, and false otherwise.    

public class RegularExpressionExample 
{

	public static void main(String[] args) 
	{
		String[] strings = {"apple", "banana", "cherry", "date", "elderberry"};

       
        String pattern = "an";

      
        Pattern regex = Pattern.compile(pattern);

      
        for (String str : strings) 
        {
            Matcher matcher = regex.matcher(str);
            if (matcher.find()) 
            {
                System.out.println(str + " contains the pattern");
            } 
            else 
            {
                System.out.println(str + " does not contain the pattern");
	
            }
	}

}
}
