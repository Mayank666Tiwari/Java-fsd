/**
 * 
 */
/**
 * 
 */
module binarysearch31 {
}