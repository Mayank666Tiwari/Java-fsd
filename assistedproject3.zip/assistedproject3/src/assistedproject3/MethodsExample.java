package assistedproject3;

public class MethodsExample 
{
	public static void greet() 
	{
        System.out.println(" Welcome to the world of methods.");
    }

    
    public static void printSum(int a, int b)
    {
        int sum = a + b;
        System.out.println("Sum: " + sum);
    }

    
    public static int calculateProduct(int a, int b) {
        int product = a * b;
        return product;
    }

	public static void main(String[] args) 
	{
		 greet(); 

	        printSum(5, 3);  

	        int result = calculateProduct(4, 6); 
	        System.out.println("Product: " + result);	

	}

}
