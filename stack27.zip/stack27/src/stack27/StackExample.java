package stack27;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		 Stack<Integer> stack = new Stack<>();

	        // Insert elements into the stack
	        stack.push(1);
	        stack.push(2);
	        stack.push(3);

	        System.out.println("Stack elements: " + stack);

	        // Remove elements from the stack
	        int removedElement = stack.pop();
	        System.out.println("Removed element: " + removedElement);
	        System.out.println("Stack elements after removal: " + stack);

	        // Insert another element into the stack
	        stack.push(4);
	        System.out.println("Stack elements after insertion: " + stack);

	        // Remove the top element without retrieving it
	        int topElement = stack.peek();
	        System.out.println("Top element (without removal): " + topElement);
	        System.out.println("Stack elements after peek: " + stack);

	}

}
