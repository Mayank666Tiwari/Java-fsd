package practiceproject2;
import java.util.Scanner;

public class EmailSearch 
{

	public static void main(String[] args) 
	{
		
        String[] emailIDs = {
                "google.abc@gmail.com",
                "yahoo.abc@gmail.com",
                "rohan.tiwari@gmail.com",
                "ram.mishra@gmail.com"
        };

        
        Scanner m = new Scanner(System.in);
        System.out.print("Enter the email ID to search: ");
        String searchEmail = m .nextLine();
       
        // Search the email ID in the array
        boolean found = false;
        for (String email : emailIDs) {
            if (email.equals(searchEmail)) {
                found = true;
                break;
            }
        }

      
        if (found) {
            System.out.println("Email ID found!");
        } 
        else 
        {
            System.out.println("Email ID not found.");
    }
}
}





