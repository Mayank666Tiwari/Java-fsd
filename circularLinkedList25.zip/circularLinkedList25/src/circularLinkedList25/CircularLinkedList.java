package circularLinkedList25;

public class CircularLinkedList {
	
	 private Node head;

	    private static class Node {
	        int data;
	        Node next;

	        Node(int data) {
	            this.data = data;
	            this.next = null;
	        }
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	            newNode.next = head;
	        } else if (data <= head.data) {
	            newNode.next = head;
	            Node current = head;
	            while (current.next != head) {
	                current = current.next;
	            }
	            current.next = newNode;
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != head && current.next.data < data) {
	                current = current.next;
	            }
	            newNode.next = current.next;
	            current.next = newNode;
	        }
	    }

	    public void display() {
	        if (head == null) {
	            System.out.println("Circular linked list is empty.");
	            return;
	        }
	        Node current = head;
	        do {
	            System.out.print(current.data + " ");
	            current = current.next;
	        } while (current != head);
	        System.out.println();
	    }


	public static void main(String[] args) 
	{
		 CircularLinkedList circularLinkedList = new CircularLinkedList();
	        circularLinkedList.insert(3);
	        circularLinkedList.insert(5);
	        circularLinkedList.insert(7);
	        circularLinkedList.insert(9);

	        System.out.println("Circular Linked List:");
	        circularLinkedList.display();

	        int newElement = 6;
	        circularLinkedList.insert(newElement);
	        System.out.println("After inserting " + newElement + ":");
	        circularLinkedList.display();

	}

}
