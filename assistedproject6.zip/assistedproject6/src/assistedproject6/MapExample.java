package assistedproject6;

import java.util.HashMap;
import java.util.Map;

public class MapExample
{

	public static void main(String[] args) 
	{
		 Map<String, Integer> map = new HashMap<>();

	    
	        map.put("John", 25);
	        map.put("Alice", 30);
	        map.put("Bob", 35);

	    
	        int johnAge = map.get("John");
	        System.out.println("John's age: " + johnAge);

	       
	        boolean aliceExists = map.containsKey("Alice");
	        System.out.println("Alice exists: " + aliceExists);

	     
	        map.put("Bob", 40);

	 
	        map.remove("John");


	        System.out.println("\nMap:");
	        for (Map.Entry<String, Integer> entry : map.entrySet()) {
	            String name = entry.getKey();
	            int age = entry.getValue();
	            System.out.println(name + ": " + age);

           }

      }
}
