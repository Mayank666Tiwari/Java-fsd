package assistedproject8;

public class StringExample 
{

	public static void main(String[] args) 
	{
		 String str = "Hello";
	        str += " World!";
	        System.out.println("String: " + str);

	       
	        StringBuffer stringBuffer = new StringBuffer("Hello");
	        stringBuffer.append(" Universe!");
	        System.out.println("StringBuffer: " + stringBuffer);

	       
	        StringBuilder stringBuilder = new StringBuilder("Hello");
	        stringBuilder.append(" Galaxy!");
	        System.out.println("StringBuilder: " + stringBuilder);

	}

}
