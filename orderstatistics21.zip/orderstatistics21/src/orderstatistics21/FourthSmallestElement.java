package orderstatistics21;

import java.util.Arrays;

public class FourthSmallestElement 
{

	public static void main(String[] args) 
	{
int[] unsortedList = {9, 3, 6, 1, 2, 8, 4, 7, 5}; 
        
        System.out.println("Unsorted list:");
        printArray(unsortedList);
        
        int fourthSmallest = findFourthSmallest(unsortedList);
        
        System.out.println("Fourth smallest element: " + fourthSmallest);
    }
    
    public static int findFourthSmallest(int[] array) 
    {
        if (array.length < 4) 
        {
            System.out.println("The array does not have a fourth smallest element.");
            return -1;
        }
        
       
        Arrays.sort(array);
        
        return array[3]; 
    }
    
    public static void printArray(int[] array) 
    {
        for (int num : array) 
        {
            System.out.print(num + " ");
        }
        System.out.println();

	}

}
