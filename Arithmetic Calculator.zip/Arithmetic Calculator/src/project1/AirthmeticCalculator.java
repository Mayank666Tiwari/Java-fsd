package project1;
import java.util.Scanner;

public class AirthmeticCalculator 
{

	public static void main(String[] args) 
	{
		
		Scanner m  = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        double num1 = m .nextDouble();

        System.out.print("Enter the second number: ");
        double num2 = m .nextDouble();

        System.out.println("Select an operation:");
        System.out.println("1. Addition (+)");
        System.out.println("2. Subtraction (-)");
        System.out.println("3. Multiplication (*)");
        System.out.println("4. Division (/)");
        System.out.print("Enter your choice: ");
        int choice = m .nextInt();

        double result = 0.0;

        switch (choice) 
        {
            case 1:
                result = num1 + num2;
                System.out.println("Addition Result: " + result);
                break;
            case 2:
                result = num1 - num2;
                System.out.println("Subtraction Result: " + result);
                break;
            case 3:
                result = num1 * num2;
                System.out.println("Multiplication Result: " + result);
                break;
            case 4:
                if (num2 != 0) {
                    result = num1 / num2;
                    System.out.println("Division Result: " + result);
                } 
                else 
                {
                    System.out.println("Error: Division by zero is not allowed!");
                }
                break;
            default:
                System.out.println("Invalid choice!");
        }

        m .close();
    }

}

