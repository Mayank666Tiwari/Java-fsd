package assistedproject4;

public class ConstructorExample 
{
	private int id;
    private String name;

    
    public ConstructorExample() {
        id = 0;
        name = "Unknown";
    }
 
    public ConstructorExample(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

	public static void main(String[] args) 
	{
		ConstructorExample obj1 = new ConstructorExample();
        ConstructorExample obj2 = new ConstructorExample(1, "John");

        System.out.println("Object 1 - ID: " + obj1.getId() + ", Name: " + obj1.getName());
        System.out.println("Object 2 - ID: " + obj2.getId() + ", Name: " + obj2.getName());
  
     }

}
